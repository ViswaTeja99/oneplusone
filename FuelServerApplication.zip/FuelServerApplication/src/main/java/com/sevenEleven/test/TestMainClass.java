package com.sevenEleven.test;


import java.io.File;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class TestMainClass {
	 public static void main(String[] args) {
		 
		 // Linked HashMap to maintain insertion order
		 Map<String,String> statusFlowMap = new LinkedHashMap<String, String>();
	      try {
	         File inputFile = new File("D:/Viswa/xml/DispenserState.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
	         System.out.println("Root Element  ::" + doc.getDocumentElement().getNodeName());
	         NodeList nList = doc.getElementsByTagName("state");
	         System.out.println("Total Number Of States :: "+nList.getLength());
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	              String currentstate = eElement
		                  .getElementsByTagName("currentstate")
		                  .item(0)
		                  .getTextContent();
	              
	              String nextstate = eElement
		                  .getElementsByTagName("nextstate")
		                  .item(0)
		                  .getTextContent();
	              statusFlowMap.put(currentstate, nextstate);
	            }
	         }
	         System.out.println("StatusFlow Map :: "+statusFlowMap);
	      } catch (Exception e) {
	        System.out.println("Exception while parsing XML");
	      }
	   }
}
