package com.sevenEleven.swagger.controller;

import javax.validation.Valid;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sevenEleven.swagger.beans.Product;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;




@RestController
@Configuration
@EnableAutoConfiguration
@ControllerAdvice
@Api(value="Fuel Server API", description="Information Of Services in Fuel Server")
public class FuelController {


	@ApiOperation(value = "Get product Information")
	@ApiResponses(value = {
	        @ApiResponse(code = 200, message = "Successfully retrieved Product Information"),
	        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
	        @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
	        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
	}
	)
	@RequestMapping(value = "/fcserver/getProduct/{id}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Product getProduct(@PathVariable Integer id,Model model)
			throws Exception {
		System.out.println("In FuelController getProduct :: id :: "+id.toString());
		Product response = new Product();
		response.setProductId(101);
		response.setProductName("Book");
		response.setProductDescription("A Journey Of 100 Centuries");
		return response;
	}
	

	@RequestMapping(value = "/fcserver/addProduct", method = RequestMethod.POST , produces = "text/plain")
	public @ResponseBody String addProduct(@Valid @RequestBody Product Product, BindingResult result)
			throws Exception {
		System.out.println("In FuelController addProduct :: addProduct :: "+Product.toString());
		
		return "Successfully Added the Product";
	}
	
}
